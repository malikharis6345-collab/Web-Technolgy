let trafficDensity = prompt("Enter traffic density (High, Medium, Low):");
let emergency = prompt("Is it emergency mode? (Yes/No):");
let greenTime;
if (emergency.toLowerCase() == "yes") {
    console.log("greenTime = 90");
}
else if (trafficDensity.toLowerCase() == "high") {
    console.log("greenTime = 60");
}
else if (trafficDensity.toLowerCase() == "medium") {
    console.log("greenTime = 40");
}
else if (trafficDensity.toLowerCase() == "low") {
    console.log("greenTime = 20");
}
else {
    greenTime = "Invalid input";
}
console.log("Green light duration:", greenTime, "seconds");
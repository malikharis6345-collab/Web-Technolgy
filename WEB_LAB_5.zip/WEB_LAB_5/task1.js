const profile = {
    productName: "D13 smart watch/D13 smart watch for boys/D20 T500/D13 smart watch strap/D13 smart watch band/D13 smart watch 2021/D13 smart watch charger/D13 watch/D13 bluetooth mobile band",
    price: 551,
    brand:"No Brand",
    color:"Black",
    rating:4.5,
    ratingCount:914,
    answeredQuestions:271,
    deliveryCharges:160,
    deliveryLocation:"Gulshan-e-Iqbal,Karachi",
    returnDays:14,
    warranty:"Not Available",
    quantity:1
};
console.log(profile);